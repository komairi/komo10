# KOMO Nota Android

Aplikasi nota sederhana untuk toko KOMO dengan printer POS Bluetooth 58 mm.

## Fitur
- Nama toko: KOMO
- Alamat: Dsn Wonosari Wetan, Kec. Glagah
- Input nama barang, harga, dan jumlah (maks. 2 digit)
- Total per barang otomatis
- Format uang Indonesia dengan titik sebagai pemisah ribuan: `18.000`
- Kertas 58 mm, layout hemat baris
- Cetak melalui Bluetooth ESC/POS
- Pilih printer dari perangkat Bluetooth yang sudah dipasangkan
- Tidak mencetak tulisan "Terima kasih" atau teks tambahan

## Membuka di Android Studio
1. Upload seluruh folder ini ke GitHub.
2. Clone/download repository.
3. Buka folder `KOMO-Nota` di Android Studio.
4. Tunggu Gradle sync.
5. Jalankan di HP Android.

## Printer
Printer harus sudah **dipasangkan (paired)** melalui pengaturan Bluetooth Android. Aplikasi kemudian menampilkan daftar printer yang sudah paired.

Printer POS 58 mm umumnya menggunakan ESC/POS melalui Bluetooth SPP. Jika printer tertentu memakai protokol berbeda, bagian `BluetoothPrinter.kt` perlu disesuaikan.

## Catatan Android 12+
Aplikasi meminta izin `BLUETOOTH_CONNECT` dan `BLUETOOTH_SCAN` saat diperlukan.
